# Insurance ontology chatbot

A simple local project with the four construction agents, an accepted semantic graph, and the React/FastAPI chatbot.

| Folder | Contains |
|---|---|
| `agents/` | Domain Expert, Manager, Coder, QA, orchestration, model client, parser and prompts |
| `artifacts/` | Accepted run: ontology, source pages, agent records, validation and CQ results |
| `chatbot/` | Backend, answer lineage and React frontend source plus production build |
| `data/` | Two synthetic research-contract PDFs, source checksums, curated facts and frozen questions |
| `ontology/` | Graph modelling, safe SPARQL, evaluation, formal checks and pattern guidance |
| `screenshots/` | Desktop and mobile application screenshots |

## Run on Windows

Open PowerShell in this folder:

```powershell
python -m venv .venv
& .\.venv\Scripts\python.exe -m pip install -r requirements.txt
& .\.venv\Scripts\python.exe run.py
```

Open **http://localhost:8000**. Use `run.py --port 8002` if needed. Stop with Ctrl+C.

On macOS/Linux use `.venv/bin/python` for the same install and launch commands. Python 3.10+ is required; the package was checked on Python 3.12. Node.js is not needed to run the bundled interface. Java is needed only to repeat the HermiT check.

## Local Qwen

Reference chat works without a model. To enable local live chat, ensure Ollama is running with `qwen3:4b`, copy `.env.example` to `.env`, then restart the app and choose **Live model**. Ollama uses port 11434; the web app uses port 8000. Model configuration and live performance must be verified on your computer.

## Try it

Select Sentinel and ask **What is the policy face amount?**, **How long is the grace period?**, or **What percentage cap applies to accelerated death benefits?** Inspect citations, agent records, actual graph edges, SPARQL and returned rows. The exact company maximum dollar limit is unspecified and should cause abstention.

The delivered graph is a curated reference fixture. Its 30/30 CQ results are not LLM extraction accuracy. Construction records in chat are retained artifacts; the four agents do not rerun for each question. History is held in browser memory, and contextual follow-up memory is not part of this baseline.

## Generate and evaluate a fresh run

Use the environment's Python executable:

```powershell
& .\.venv\Scripts\python.exe -m agents.cli run --mode demo --output artifacts/demo-new
& .\.venv\Scripts\python.exe -m agents.cli evaluate --run artifacts/demo-new
# With an actual model configured:
& .\.venv\Scripts\python.exe -m agents.cli run --mode llm --output artifacts/live-001 --require-dl
& .\.venv\Scripts\python.exe -m agents.cli evaluate --run artifacts/live-001 --mode llm
```

Choose a new folder for each run. Restart the app and select the accepted run. `--require-dl` requires Java and blocks publication if HermiT is unavailable or fails. The optional vector method requires `sentence-transformers`; optional architectural judging uses `ontology/judging_panel.example.json` after you configure a real panel.

## Edit the frontend, if needed

```powershell
npm ci --prefix chatbot/frontend
npm run build --prefix chatbot/frontend
```

The development command `npm run dev --prefix chatbot/frontend` proxies to the backend on port 8000. API documentation is at **http://localhost:8000/api/docs**. Keep the default localhost binding for this local PoC.

Verification after rearrangement: 45 automated checks, 27 actual browser checks, a fresh four-role demo generation with 30/30 reference CQs, and HermiT validation passed. These are engineering/reference checks; live Qwen quality remains unmeasured here.
