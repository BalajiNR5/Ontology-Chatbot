import os,statistics
from pathlib import Path
from agents.llm import LLM
from agents.io import read_json,write_json
from agents.models import ArchitectureScore

def review_architecture(run_dir,panel_path):
    folder=Path(run_dir);panel=read_json(panel_path);results=[]
    if not panel.get('judges'):raise ValueError('At least one configured judge is required')
    for judge in panel['judges']:
        if judge['model'].startswith('REPLACE_'):raise ValueError('Replace example judge models before running')
        llm=LLM(folder/'architecture_calls',judge=True,base_url=judge['base_url'],model_name=judge['model'],
                api_key=os.getenv(judge['api_key_env'],'not-needed'))
        score=llm.call('architecture',{'ontology':(folder/'ontology.ttl').read_text(),
                     'run_mode':read_json(folder/'run_manifest.json')['mode']},ArchitectureScore)
        results.append({'judge_id':judge['id'],'model':judge['model'],**score.model_dump()})
    keys=['extensibility','redundancy_avoidance','odp_usage']
    report={'results':results,'means':{k:statistics.mean(r[k] for r in results) for k in keys},
            'human_review_status':'pending','reliability':'Krippendorff alpha not estimated from a single artifact; collect repeated artifact ratings first.'}
    write_json(folder/'architecture_review.json',report);return report
