import argparse,json
from pathlib import Path
from agents.io import ROOT,write_json,parse_document

def main():
    parser=argparse.ArgumentParser(description='Paper-aligned insurance ontology PoC')
    sub=parser.add_subparsers(dest='command',required=True)
    run=sub.add_parser('run');run.add_argument('--mode',choices=['demo','llm'],default='demo')
    run.add_argument('--input',nargs='+');run.add_argument('--output',default='artifacts/demo')
    run.add_argument('--require-dl',action='store_true')
    ev=sub.add_parser('evaluate');ev.add_argument('--run',default='artifacts/demo');ev.add_argument('--mode',choices=['demo','llm'],default='demo')
    ev.add_argument('--split',choices=['all','development','heldout'],default='all');ev.add_argument('--method',choices=['sparql','vector'],default='sparql')
    chat=sub.add_parser('chat');chat.add_argument('--run',default='artifacts/demo');chat.add_argument('--contract',default='sentinel')
    chat.add_argument('--mode',choices=['demo','llm'],default='demo');chat.add_argument('question')
    cq=sub.add_parser('generate-cqs');cq.add_argument('--input',required=True);cq.add_argument('--output',required=True)
    val=sub.add_parser('validate');val.add_argument('--run',default='artifacts/demo');val.add_argument('--require-dl',action='store_true')
    arch=sub.add_parser('review-architecture');arch.add_argument('--run',required=True);arch.add_argument('--panel',required=True)
    args=parser.parse_args()
    if args.command=='review-architecture':
        from agents.architecture import review_architecture
        print(json.dumps(review_architecture(args.run,args.panel),indent=2))
    elif args.command=='run':
        from agents.pipeline import run_pipeline
        inputs=[Path(p) for p in args.input] if args.input else [ROOT/'data/raw/equivita.pdf',ROOT/'data/raw/sentinel.pdf']
        output=run_pipeline(inputs,Path(args.output),args.mode,args.require_dl);print(f'Validated artifacts: {output}')
    elif args.command=='evaluate':
        from ontology.evaluation import evaluate
        print(json.dumps(evaluate(args.run,args.mode,args.split,args.method)['summary'],indent=2))
    elif args.command=='chat':
        from chatbot.core import ask
        print(json.dumps(ask(args.run,args.contract,args.question,args.mode),indent=2))
    elif args.command=='generate-cqs':
        from agents.llm import LLM
        from agents.models import CQSet
        llm=LLM();out=[]
        for page in parse_document(args.input):
            cqs=llm.call('cq',page.model_dump(),CQSet)
            out.append({'document_id':page.document_id,'page':page.page,'questions':[q.model_dump() for q in cqs.questions],
                        'review_status':'pending; curate and freeze before benchmarking'})
        write_json(args.output,out);print(f'Generated CQ candidates: {args.output}')
    elif args.command=='validate':
        from ontology.validation import validate_turtle
        from agents.models import Page
        from agents.io import read_json
        folder=Path(args.run);pages=[Page.model_validate(p) for p in read_json(folder/'pages.json')]
        result,_=validate_turtle((folder/'ontology.ttl').read_text(),pages,args.require_dl)
        write_json(folder/'validation_recheck.json',result);print(json.dumps(result,indent=2))
        if not result['passed']:raise SystemExit(1)
if __name__=='__main__':main()
