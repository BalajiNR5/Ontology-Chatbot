import hashlib, json, re
from pathlib import Path
from agents.models import Page

ROOT = Path(__file__).resolve().parents[1]
def write_json(path, value):
    path=Path(path); path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps(value,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
def read_json(path):
    return json.loads(Path(path).read_text(encoding='utf-8'))
def normalize(text):
    return re.sub(r'\s+',' ',text).strip()
def parse_document(path, document_id=None):
    path=Path(path); doc_id=document_id or re.sub(r'[^a-zA-Z0-9_]','_',path.stem).lower()
    suffix=path.suffix.lower()
    if suffix=='.pdf':
        from pypdf import PdfReader
        reader=PdfReader(path)
        texts=[p.extract_text() or '' for p in reader.pages]
        if not any(normalize(t) for t in texts):
            raise ValueError('Scanned PDF has no text layer. OCR it first; empty text is never accepted.')
    elif suffix=='.txt': texts=[path.read_text(encoding='utf-8')]
    elif suffix=='.docx':
        from docx import Document
        doc=Document(path); texts=[]; current=[]
        for p in doc.paragraphs:
            if p.style.name.startswith('Heading') and current:
                texts.append('\n'.join(current)); current=[]
            current.append(p.text)
        for table in doc.tables:
            current.extend(' | '.join(c.text for c in row.cells) for row in table.rows)
        if current: texts.append('\n'.join(current))
    elif suffix=='.pptx':
        from pptx import Presentation
        texts=['\n'.join(s.text for s in slide.shapes if s.has_text_frame) for slide in Presentation(path).slides]
    else: raise ValueError(f'Unsupported format: {suffix}')
    pages=[]
    for i,text in enumerate(texts,1):
        if not normalize(text): continue
        pages.append(Page(document_id=doc_id,page=i,text=text,sha256=hashlib.sha256(text.encode()).hexdigest(),source_path=path.name))
    if not pages: raise ValueError('Document contains no usable structural units')
    return pages
