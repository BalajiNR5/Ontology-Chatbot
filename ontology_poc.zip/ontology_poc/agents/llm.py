import json, os, time, urllib.request, urllib.error
from dotenv import load_dotenv
from agents.io import ROOT, write_json

class LLM:
    """Small OpenAI-compatible client. No provider-specific SDK is required."""
    def __init__(self,log_dir=None,judge=False,base_url=None,model_name=None,api_key=None):
        load_dotenv(ROOT/'.env',override=False)
        prefix='JUDGE_' if judge else 'LLM_'
        self.base=(base_url or os.getenv(prefix+'BASE_URL') or os.getenv('LLM_BASE_URL','http://localhost:11434/v1')).rstrip('/')
        self.key=api_key or os.getenv(prefix+'API_KEY') or os.getenv('LLM_API_KEY','not-needed')
        self.model=model_name or os.getenv(prefix+'MODEL') or os.getenv('LLM_MODEL','')
        if not self.model: raise ValueError('Set LLM_MODEL in .env for live mode')
        if not self.base.startswith(('http://','https://')): raise ValueError('Endpoint must be HTTP(S)')
        from pathlib import Path
        from uuid import uuid4
        self.log_dir=Path(log_dir)/uuid4().hex if log_dir else None; self.calls=[]
    def call(self,role,context,model):
        prompt=(ROOT/'agents/prompts'/f'{role}.txt').read_text(encoding='utf-8')
        system=prompt+'\nReturn ONLY JSON matching this schema:\n'+json.dumps(model.model_json_schema())
        payload={'model':self.model,'temperature':0,'max_tokens':int(os.getenv('LLM_MAX_TOKENS','12000')),
                 'messages':[{'role':'system','content':system},{'role':'user','content':json.dumps(context,ensure_ascii=False)}]}
        started=time.monotonic(); last=None
        for attempt in range(3):
            try:
                req=urllib.request.Request(self.base+'/chat/completions',json.dumps(payload).encode(),
                    {'Content-Type':'application/json','Authorization':'Bearer '+self.key})
                with urllib.request.urlopen(req,timeout=float(os.getenv('LLM_TIMEOUT_SECONDS','120'))) as response:
                    data=json.load(response)
                body=data['choices'][0]['message']['content'].strip()
                if body.startswith('```'): body='\n'.join(body.splitlines()[1:-1])
                result=model.model_validate_json(body)
                record={'role':role,'model':self.model,'seconds':round(time.monotonic()-started,3),
                        'usage':data.get('usage',{}),'attempts':attempt+1,'output':result.model_dump()}
                self.calls.append(record)
                if self.log_dir: write_json(self.log_dir/f'{len(self.calls):04d}_{role}.json',record)
                return result
            except urllib.error.HTTPError as e:
                # Do not echo upstream response bodies or credentials.
                if e.code not in (429,500,502,503,504): raise RuntimeError(f'LLM HTTP {e.code}') from None
                last=f'HTTP {e.code}'
            except (urllib.error.URLError,TimeoutError) as e: last=type(e).__name__
            except (ValueError,KeyError) as e:
                last=f'Invalid structured response: {type(e).__name__}'
                payload['messages'].append({'role':'user','content':'The response did not satisfy the JSON schema. Regenerate complete valid JSON.'})
            if attempt<2: time.sleep(attempt+1)
        raise RuntimeError(f'LLM call failed after 3 attempts: {last}')
