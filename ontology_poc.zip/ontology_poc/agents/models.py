from typing import Literal
from pydantic import BaseModel, Field, ConfigDict

class StrictModel(BaseModel):
    model_config = ConfigDict(extra='forbid')

class Page(StrictModel):
    document_id: str
    page: int = Field(ge=1)
    text: str
    sha256: str
    source_path: str

class Concept(StrictModel):
    name: str
    kind: Literal['Entity','Role','Event','State','Attribute','TimeInterval','MonetaryAmount','Rule']
    description: str

class Relationship(StrictModel):
    source: str
    label: str
    target: str
    qualifiers: list[str] = Field(default_factory=list)

class Requirement(StrictModel):
    id: str
    cq_ids: list[str]
    evidence_quote: str
    concepts: list[Concept]
    relationships: list[Relationship]
    constraints: list[str]

class SRD(StrictModel):
    document_id: str
    page: int
    requirements: list[Requirement]
    uncertainties: list[str] = Field(default_factory=list)

class Design(StrictModel):
    concept: str
    intent: str
    patterns: list[str]
    classes: list[str]
    properties: list[str]

class Alignment(StrictModel):
    cq_id: str
    requirement_ids: list[str]
    classes: list[str]
    properties: list[str]
    query_strategy: str

class TIP(StrictModel):
    document_id: str
    page: int
    conceptual_model: list[Design]
    reuse: list[str]
    new_terms: list[str]
    cq_alignment: list[Alignment]

class CoderOutput(StrictModel):
    turtle: str
    change_summary: list[str]

class Finding(StrictModel):
    severity: Literal['error','warning']
    lines: str
    description: str

class Review(StrictModel):
    status: Literal['PASS','CHANGES_REQUIRED']
    findings: list[Finding]

class Patch(StrictModel):
    old: str
    new: str

class Repair(StrictModel):
    patches: list[Patch]
    rationale: str

class QueryOutput(StrictModel):
    sparql: str

class Score(StrictModel):
    score: float = Field(ge=0,le=1)
    justification: str

class GeneratedCQ(StrictModel):
    competency_question: str
    expected_answer: str

class CQSet(StrictModel):
    questions: list[GeneratedCQ]

class ArchitectureScore(StrictModel):
    extensibility: int = Field(ge=1,le=5)
    redundancy_avoidance: int = Field(ge=1,le=5)
    odp_usage: int = Field(ge=1,le=5)
    justification: str
