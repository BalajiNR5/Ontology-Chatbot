import hashlib,os,time
from pathlib import Path
from rdflib.namespace import RDF,OWL
from agents.io import ROOT,read_json,write_json,parse_document
from ontology.graph import EX,new_graph,reference_schema,add_source,numbered,stats,registry
from agents.llm import LLM
from agents.roles import DomainExpert,Manager,Coder,QualityAssurer
from ontology.validation import validate_turtle,patch_turtle

def run_pipeline(inputs,output,mode='demo',require_dl=False):
    output=Path(output)
    if (output/'run_manifest.json').exists():raise ValueError('Output already contains a run. Choose a new output directory to preserve audit history.')
    output.mkdir(parents=True,exist_ok=True)
    pages=[]
    for path in inputs:pages.extend(parse_document(path))
    write_json(output/'pages.json',[p.model_dump() for p in pages])
    cqs=read_json(ROOT/'data/cqs/development.json')
    fixture_facts=read_json(ROOT/'data/fixtures/facts.json') if mode=='demo' else []
    if mode=='demo' and any(p.document_id not in {'equivita','sentinel'} for p in pages):raise ValueError('Demo fixtures support the two bundled contracts only. Use --mode llm for new documents.')
    catalog=read_json(ROOT/'ontology/odp_catalog.json')
    llm=LLM(output/'llm_calls') if mode=='llm' else None
    agents=[DomainExpert(llm),Manager(llm),Coder(llm),QualityAssurer(llm)]
    domain,manager,coder,qa=agents
    g=reference_schema() if mode=='demo' else new_graph()
    if mode=='llm':g.add((EX.InsuranceOntology,RDF.type,OWL.Ontology))
    # Pre-register immutable pages for cross-page evidence and role references.
    for page in pages:add_source(g,page)
    initial=set(g);history=[];started=time.monotonic()
    run={'mode':mode,'is_llm_measured':mode=='llm','status':'running','require_dl':require_dl,
         'model':llm.model if llm else None,'human_review_status':'pending','documents':sorted({p.document_id for p in pages}),
         'source_sha256':{str(Path(p)):hashlib.sha256(Path(p).read_bytes()).hexdigest() for p in inputs}}
    write_json(output/'run_manifest.json',run)
    try:
        for page in pages:
            development=[q for q in cqs if q['document_id']==page.document_id and q['page']==page.page]
            facts=[f for f in fixture_facts if f['document_id']==page.document_id and f['page']==page.page]
            previous=set(g);folder=output/'agents'/page.document_id/f'page_{page.page:03d}'
            srd=domain.run(page,development,facts);write_json(folder/'01_srd.json',srd.model_dump())
            tip=manager.run(srd,g,development,catalog);write_json(folder/'02_tip.json',tip.model_dump())
            if tip.document_id!=page.document_id or tip.page!=page.page:raise ValueError('TIP page identity changed')
            candidate=coder.run(page,srd,tip,g,facts);turtle=candidate.turtle
            folder.mkdir(parents=True,exist_ok=True);(folder/'03_candidate.ttl').write_text(turtle,encoding='utf-8')
            write_json(folder/'03_changes.json',candidate.change_summary)
            seen=set();accepted=False
            for attempt in range(int(os.getenv('MAX_QA_REPAIRS','3'))+1):
                fingerprint=hashlib.sha256(turtle.encode()).hexdigest()
                if fingerprint in seen:raise ValueError('QA loop repeated a previous snapshot')
                seen.add(fingerprint)
                review=qa.run(page,srd,tip,turtle,catalog)
                # Every candidate passes formal gates; the final whole-document gate repeats them.
                validation,parsed=validate_turtle(turtle,pages,require_dl=False)
                preservation=parsed is not None and previous.issubset(set(parsed))
                arch_ok=review.status=='PASS' and not any(f.severity=='error' for f in review.findings)
                formal_ok=validation['passed']
                # Empty early pages are acceptable until the first provision exists.
                if not srd.requirements and not list(g.subjects(RDF.type,EX.Provision)):
                    formal_ok=validation['syntax']['status']=='pass' and validation['owl_rl']['status']=='pass'
                report={'attempt':attempt,'architectural':review.model_dump(),'formal':validation,'preserves_previous_triples':preservation,
                        'architecture_review_method':'LLM' if llm else 'deterministic fixture assertion; independent architecture review not performed'}
                write_json(folder/f'04_qa_{attempt}.json',report)
                if arch_ok and formal_ok and preservation:
                    g=parsed;accepted=True;break
                if not llm or attempt==int(os.getenv('MAX_QA_REPAIRS','3')):break
                repair=coder.repair({'page':page.model_dump(),'srd':srd.model_dump(),'tip':tip.model_dump(),
                       'findings':report,'ontology_with_line_numbers':numbered(turtle)})
                write_json(folder/f'05_repair_{attempt}.json',repair.model_dump())
                turtle=patch_turtle(turtle,repair.patches)
            if not accepted:raise ValueError(f'Page {page.document_id}/{page.page} failed QA; nothing published')
            history.append({'document_id':page.document_id,'page':page.page,'requirements':len(srd.requirements),'qa_attempts':attempt+1})
        final=g.serialize(format='turtle')
        validation,g=validate_turtle(final,pages,require_dl)
        write_json(output/'validation.json',validation)
        if not validation['passed']:raise ValueError('Final document validation failed; nothing published')
        g.serialize(output/'ontology.ttl',format='turtle');g.serialize(output/'ontology.owl',format='xml')
        write_json(output/'registry.json',registry(g));write_json(output/'statistics.json',stats(g))
        run.update(status='validated',seconds=round(time.monotonic()-started,3),page_history=history,
                   llm_calls=len(llm.calls) if llm else 0,ontology_sha256=hashlib.sha256((output/'ontology.ttl').read_bytes()).hexdigest())
    except Exception as e:
        run.update(status='failed',error=str(e),seconds=round(time.monotonic()-started,3))
        write_json(output/'run_manifest.json',run);raise
    write_json(output/'run_manifest.json',run)
    return output
