from agents.models import SRD,TIP,CoderOutput,Review,Repair
from ontology.graph import registry,numbered,add_fixture,reference_schema
from agents.io import normalize

class DomainExpert:
    name='domain'
    def __init__(self,llm=None):self.llm=llm
    def run(self,page,cqs,facts):
        if self.llm:
            srd=self.llm.call('domain',{'page':page.model_dump(),'development_cqs':cqs},SRD)
            if srd.document_id!=page.document_id or srd.page!=page.page:raise ValueError('SRD changed page identity')
            for req in srd.requirements:
                if not normalize(req.evidence_quote) or normalize(req.evidence_quote) not in normalize(page.text):raise ValueError('SRD evidence is not grounded in source page')
            return srd
        requirements=[]
        for f in facts:
            concept={'money':'MonetaryAmount','interval':'TimeInterval','quantity':'Attribute','role':'Role','event':'Event','rule':'Rule'}[f['kind']]
            requirements.append({'id':f['id'],'cq_ids':[q['id'] for q in cqs if q['fact_id']==f['id']],
                'evidence_quote':f['quote'],'concepts':[{'name':concept,'kind':concept,'description':f['statement']}],
                'relationships':[{'source':'Policy','label':'hasProvision','target':f['id']}],
                'constraints':f['conditions']+([f"{f['value']} {f['unit']}"] if f['value'] else [])})
        return SRD(document_id=page.document_id,page=page.page,requirements=requirements,
                   uncertainties=['Deterministic fixture replay: curated facts, not measured LLM extraction.'])

class Manager:
    name='manager'
    def __init__(self,llm=None):self.llm=llm
    def run(self,srd,g,cqs,catalog):
        if self.llm:return self.llm.call('manager',{'srd':srd.model_dump(),'registry':registry(g),'development_cqs':cqs,'odp_catalog':catalog},TIP)
        model=[]
        for req in srd.requirements:
            kind=req.concepts[0].kind
            pattern={'MonetaryAmount':'QuantitiesAndUnits','TimeInterval':'TimeInterval','Attribute':'QuantitiesAndUnits',
                     'Role':'AgentRole','Event':'Event','Rule':'ConditionalRule'}[kind]
            model.append({'concept':req.id,'intent':req.concepts[0].description,'patterns':[pattern],
                          'classes':[req.concepts[0].name,'Provision'],'properties':['hasProvision','sourcePage']})
        return TIP(document_id=srd.document_id,page=srd.page,conceptual_model=model,
                   reuse=[x['uri'] for x in registry(g)],new_terms=[],
                   cq_alignment=[{'cq_id':q['id'],'requirement_ids':[q['fact_id']],'classes':['Provision'],
                                  'properties':['hasProvision'],'query_strategy':'Traverse policy provision into structured amount, interval, role, event or qualified rule.'} for q in cqs])

class Coder:
    name='coder'
    def __init__(self,llm=None):self.llm=llm
    def run(self,page,srd,tip,g,facts):
        if self.llm:return self.llm.call('coder',{'page':page.model_dump(),'srd':srd.model_dump(),'tip':tip.model_dump(),
                          'ontology_with_line_numbers':numbered(g.serialize(format='turtle'))},CoderOutput)
        planned={m.concept for m in tip.conceptual_model}
        if {f['id'] for f in facts}!=planned:raise ValueError('Fixture coder received facts outside TIP')
        add_fixture(g,page,facts)
        return CoderOutput(turtle=g.serialize(format='turtle'),change_summary=[f'Encoded grounded provision {f["id"]}' for f in facts])
    def repair(self,context):
        if not self.llm:raise RuntimeError('Demo mode does not synthesize repairs')
        return self.llm.call('repair',context,Repair)

class QualityAssurer:
    name='qa'
    def __init__(self,llm=None):self.llm=llm
    def run(self,page,srd,tip,turtle,catalog):
        if self.llm:return self.llm.call('qa',{'page':page.model_dump(),'srd':srd.model_dump(),'tip':tip.model_dump(),
                         'ontology_with_line_numbers':numbered(turtle),'odp_catalog':catalog},Review)
        return Review(status='PASS',findings=[])
