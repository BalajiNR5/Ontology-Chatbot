"""Local FastAPI backend and bundled React frontend.

Chat progress is emitted by real backend operations, not fabricated timer steps.
"""
import asyncio,hashlib,json,os,queue,re,threading
from pathlib import Path
from typing import Literal
from fastapi import FastAPI,HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse,StreamingResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel,Field,field_validator
from dotenv import load_dotenv
from agents.io import ROOT,read_json
from chatbot.core import ask
from chatbot.lineage import ARTIFACTS

app=FastAPI(title='Semantic Workbench API',version='2.0.0',docs_url='/api/docs',openapi_url='/api/openapi.json')
app.add_middleware(CORSMiddleware,allow_origins=['http://localhost:5173','http://127.0.0.1:5173'],allow_methods=['GET','POST'],allow_headers=['Content-Type'])
RUN_ROOT=ROOT/'artifacts'

def run_folder(run_id):
    if not re.fullmatch(r'[A-Za-z0-9_-][A-Za-z0-9_.-]{0,79}',run_id):raise HTTPException(404,'Run not found')
    folder=(RUN_ROOT/run_id).resolve()
    if folder.parent!=RUN_ROOT.resolve() or not (folder/'ontology.ttl').is_file():raise HTTPException(404,'Run not found')
    try:manifest=read_json(folder/'run_manifest.json');validation=read_json(folder/'validation.json')
    except (OSError,ValueError):raise HTTPException(409,'The run has incomplete audit records')
    if manifest.get('status')!='validated' or not validation.get('passed'):raise HTTPException(409,'The run has not passed its acceptance checks')
    if hashlib.sha256((folder/'ontology.ttl').read_bytes()).hexdigest()!=manifest.get('ontology_sha256'):
        raise HTTPException(409,'The ontology changed after validation. Revalidate a new run before using it.')
    return folder

def model_ready():
    load_dotenv(ROOT/'.env',override=False)
    return bool(os.getenv('LLM_MODEL'))

class ChatRequest(BaseModel):
    run_id: str='demo'
    document_id: str
    question: str=Field(min_length=1,max_length=2000)
    mode: Literal['demo','llm']='demo'
    @field_validator('question')
    @classmethod
    def nonblank(cls,v):
        v=v.strip()
        if not v:raise ValueError('Enter a question')
        return v

def checked_request(body):
    folder=run_folder(body.run_id);manifest=read_json(folder/'run_manifest.json')
    if body.document_id not in manifest['documents']:raise HTTPException(404,'Contract is not part of this run')
    if body.mode=='llm' and not model_ready():raise HTTPException(409,'Live model is not configured. Use reference mode or configure the model endpoint.')
    return folder

@app.get('/api/health')
def health():return {'status':'ok','version':'2.0.0'}

@app.get('/api/workspace')
def workspace(run_id:str='demo'):
    folder=run_folder(run_id);manifest=read_json(folder/'run_manifest.json');pages=read_json(folder/'pages.json')
    source=read_json(ROOT/'data/source_manifest.json')
    from ontology.graph import EX,DATA,new_graph
    graph=new_graph().parse(folder/'ontology.ttl',format='turtle')
    names={'equivita':'Equivita Mutual Life','sentinel':'Sentinel Life Assurance'}
    runs=[]
    for p in sorted(RUN_ROOT.iterdir()):
        if p.is_dir() and (p/'ontology.ttl').is_file():
            try:
                m=read_json(p/'run_manifest.json')
                if m.get('status')=='validated':runs.append({'id':p.name,'mode':m.get('mode'),'label':p.name})
            except (OSError,ValueError):continue
    contracts=[]
    for doc in manifest['documents']:
        docpages=[p for p in pages if p['document_id']==doc]
        contracts.append({'id':doc,'name':names.get(doc,doc),'pages':len(docpages),
                          'provisions':len(list(graph.objects(DATA[doc],EX.hasProvision))),
                          'type':'20-year level term' if doc in names else 'Contract','synthetic':doc in names,
                          'pdf_url':f'/api/sources/{doc}/pdf'})
    return {'run':{'id':run_id,'mode':manifest['mode'],'status':manifest['status'],'human_review_status':manifest['human_review_status']},
            'runs':runs,'contracts':contracts,'statistics':read_json(folder/'statistics.json'),
            'validation':read_json(folder/'validation.json'),'live_model_configured':model_ready(),
            'source_repository':source['repository']}

@app.post('/api/chat')
def chat(body:ChatRequest):
    folder=checked_request(body)
    try:return ask(folder,body.document_id,body.question,body.mode)
    except Exception as e:raise HTTPException(502,f'Could not complete the graph query ({type(e).__name__}). Check the configured model and audit records.') from None

@app.post('/api/chat/stream')
def stream_chat(body:ChatRequest):
    folder=checked_request(body);events=queue.Queue()
    def worker():
        try:
            result=ask(folder,body.document_id,body.question,body.mode,progress=lambda event:events.put(('progress',event)))
            events.put(('result',result))
        except Exception as e:
            events.put(('error',{'message':f'Could not complete the query ({type(e).__name__}). Check model connectivity and audit records.'}))
    threading.Thread(target=worker,daemon=True).start()
    async def event_stream():
        while True:
            try:kind,data=await asyncio.to_thread(events.get,True,15)
            except queue.Empty:
                yield ': keepalive\n\n';continue
            yield 'event: '+kind+'\ndata: '+json.dumps(data,ensure_ascii=False)+'\n\n'
            if kind in ['result','error']:break
    return StreamingResponse(event_stream(),media_type='text/event-stream',headers={'Cache-Control':'no-cache','X-Accel-Buffering':'no'})

@app.get('/api/sources/{document_id}/pdf')
def source_pdf(document_id:str):
    manifest=read_json(ROOT/'data/source_manifest.json')
    doc=next((d for d in manifest['documents'] if d['id']==document_id),None)
    if not doc:raise HTTPException(404,'Source document not found')
    path=ROOT/doc['path']
    if not path.is_file() or hashlib.sha256(path.read_bytes()).hexdigest()!=doc['sha256']:raise HTTPException(409,'Source PDF differs from the frozen source manifest')
    return FileResponse(path,media_type='application/pdf')

@app.get('/api/runs/{run_id}/sources/{document_id}')
def source_pages(run_id:str,document_id:str):
    folder=run_folder(run_id);pages=[p for p in read_json(folder/'pages.json') if p['document_id']==document_id]
    if not pages:raise HTTPException(404,'Source document not found in run')
    return {'document_id':document_id,'pages':pages}

@app.get('/api/runs/{run_id}/artifact/{artifact_id}')
def agent_artifact(run_id:str,artifact_id:str):
    folder=run_folder(run_id)
    try:doc,page,kind=artifact_id.split(':');page=int(page)
    except ValueError:raise HTTPException(404,'Artifact not found')
    if doc not in read_json(folder/'run_manifest.json')['documents'] or page<1 or kind not in ARTIFACTS:raise HTTPException(404,'Artifact not found')
    page_dir=folder/'agents'/doc/f'page_{page:03d}'
    path=page_dir/ARTIFACTS[kind]
    if kind=='qa':
        choices=sorted(page_dir.glob('04_qa_*.json'))
        if choices:path=choices[-1]
    if not path.is_file():raise HTTPException(404,'This artifact was not retained for this page')
    return {'name':path.name,'content':read_json(path) if path.suffix=='.json' else path.read_text(),'kind':kind}

@app.get('/api/runs/{run_id}/evaluation')
def evaluation(run_id:str):
    folder=run_folder(run_id)
    reports=[{'filename':p.name,**read_json(p)} for p in sorted(folder.glob('evaluation_*.json'))]
    negative=read_json(folder/'negative_controls.json') if (folder/'negative_controls.json').is_file() else None
    tests=read_json(folder/'delivery_verification.json').get('tests') if (folder/'delivery_verification.json').is_file() else None
    return {'reports':reports,'negative_controls':negative,'tests':tests,'validation':read_json(folder/'validation.json')}

@app.get('/api/runs/{run_id}/download/{filename}')
def download(run_id:str,filename:str):
    folder=run_folder(run_id)
    if filename not in ['ontology.ttl','ontology.owl','validation.json','statistics.json','registry.json','delivery_verification.json']:
        raise HTTPException(404,'Download not found')
    path=folder/filename
    if not path.is_file():raise HTTPException(404,'Download not available')
    return FileResponse(path,filename=filename)

frontend=ROOT/'chatbot/frontend/dist'
if frontend.is_dir():app.mount('/',StaticFiles(directory=frontend,html=True),name='frontend')
