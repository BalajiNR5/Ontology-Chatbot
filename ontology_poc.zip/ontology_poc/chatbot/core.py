import re
from pathlib import Path
from pydantic import Field
from agents.models import StrictModel,QueryOutput
from ontology.graph import EX,DATA,new_graph,registry
from ontology.query import safe_query,scoped_graph,fixture_query,row_answer
from agents.io import ROOT,read_json
from agents.llm import LLM

class Answer(StrictModel):
    answer: str
    evidence: list[str] = Field(default_factory=list)

INTENTS={
 'face':['face amount','coverage amount','sum assured'],
 'premium':['premium amount','stated premium','premium cost','annual premium','monthly premium'],
 'owner':['policy owner','policyholder name','who owns'],
 'beneficiary':['primary beneficiary','who is the beneficiary','named beneficiary'],
 'grace':['how long grace period','grace period duration','how many days grace'],
 'reinstatement':['how long after lapse reinstatement','reinstatement deadline','reinstate within'],
 'suicide':['how long suicide exclusion','suicide exclusion period duration'],
 'contest':['how long contestability','contestability period duration'],
 'death':['conditions trigger payment death benefit','when death benefit paid','death benefit conditions'],
 'lapse':['premiums unpaid after grace period','lapse nonpayment','what happens unpaid'],
 'grace_death':['deduction insured dies during grace period','death during grace unpaid premium'],
 'law':['which state law governs','governing law','jurisdiction'],
 'consent':['irrevocable beneficiary consent','changing irrevocable beneficiary requires'],
 'simultaneous':['uncertain simultaneous death','order of death uncertain'],
 'suicide_refund':['what is paid suicide within exclusion','suicide premiums refund'],
 'adb_cap':['percentage cap accelerated death benefits','accelerated benefit percent limit'],
 'terminal':['life expectancy required accelerated death benefit','terminal illness months'],
 'adb_exclusions':['causes terminal illness exclude accelerated benefit','accelerated benefit exclusions']}

def tokens(s):
    return set(re.findall(r'[a-z0-9]+',s.lower()))-{'what','is','the','a','an','of','to','for','does','this','policy','how','in','be','it','with','if','when'}

def demo_intent(question):
    q=tokens(question)
    # Unspecified exact numeric limits are explicit abstention controls.
    if ('exact' in q or 'maximum' in q) and ('age' in q or ('dollar' in q and 'company' in q)):return None
    ranked=[]
    for key,examples in INTENTS.items():
        best=max(len(q&tokens(e))/max(len(q|tokens(e)),1) for e in examples)
        ranked.append((best,key))
    ranked.sort(reverse=True)
    if not ranked or ranked[0][0]<0.38:return None
    if len(ranked)>1 and ranked[0][0]-ranked[1][0]<0.06:return None
    return ranked[0][1]

def _evidence(g,provisions):
    evidence=[]
    for node in sorted(set(provisions),key=str):
        source=g.value(node,EX.sourcePage)
        if source is None:continue
        page=g.value(source,EX.pageNumber);doc=g.value(source,EX.documentId)
        quote=g.value(node,EX.evidenceQuote)
        if quote is not None:evidence.append({'document_id':str(doc),'page':int(page),'quote':str(quote),
                  'provision':str(node),'conditions':[str(c) for c in g.objects(node,EX.condition)]})
    return evidence

def ask(run_dir,document_id,question,mode='demo',progress=None):
    import time
    started=time.monotonic();timeline=[]
    def emit(stage,state,detail):
        event={'stage':stage,'state':state,'detail':detail,'elapsed_ms':round((time.monotonic()-started)*1000)}
        timeline.append(event)
        if progress:progress(event)
    def finish(result):
        result['timeline']=timeline
        result['duration_ms']=round((time.monotonic()-started)*1000)
        emit('complete','complete','Answer ready with source lineage.' if not result['abstained'] else 'No supported answer found; no facts were invented.')
        return result
    emit('graph','running','Loading the accepted ontology and isolating the selected contract.')
    folder=Path(run_dir);g=new_graph().parse(folder/'ontology.ttl',format='turtle');scoped=scoped_graph(g,document_id)
    result={'question':question,'document_id':document_id,'answer':'The selected contract graph does not contain enough verified information to answer this question.',
            'abstained':True,'sparql':None,'rows':[],'evidence':[],'mode':mode,'lineage':None}
    emit('graph','complete','Selected contract graph is loaded. Other policy instances are excluded.')
    emit('query','running','Matching a supported semantic intent.' if mode=='demo' else 'Generating a query using the accepted ontology vocabulary.')
    if mode=='demo':
        key=demo_intent(question)
        if not key:
            emit('query','abstained','This question is unsupported, ambiguous, or asks for an unstated precise value.')
            return finish(result)
        facts=read_json(ROOT/'data/fixtures/facts.json')
        fact=next((f for f in facts if f['document_id']==document_id and f['id']==f'{document_id}_{key}'),None)
        if not fact:
            emit('query','abstained','The selected policy does not contain that reference provision.')
            return finish(result)
        query=fixture_query({'fact_id':fact['id'],'kind':fact['kind']})
    else:
        llm=LLM();query=llm.call('query',{'question':question,'contract_uri':str(DATA[document_id]),
               'ontology_registry':registry(scoped),'ontology_turtle':scoped.serialize(format='turtle'),
               'requirements':'SELECT must also project ?provision (a URI of an ex:Provision) so evidence can be verified.'},QueryOutput).sparql
    emit('query','complete','A local, fact-reading SPARQL query has been selected.')
    emit('execution','running','Validating and executing SPARQL against the selected graph.')
    try:rows=safe_query(scoped,query)
    except Exception as e:
        result.update(query_error=str(e),sparql=query)
        emit('execution','abstained','The query was rejected or could not be executed.')
        return finish(result)
    result.update(sparql=query,rows=rows)
    emit('execution','complete',f'Retrieved {len(rows)} result row(s).')
    emit('evidence','running','Resolving original source pages and retained agent artifacts.')
    if mode=='demo':evidence=_evidence(scoped,[DATA[fact['id']]])
    else:
        provisions=[]
        from rdflib import URIRef
        from rdflib.namespace import RDF
        for row in rows:
            if 'provision' in row and (URIRef(row['provision']),RDF.type,EX.Provision) in scoped:provisions.append(URIRef(row['provision']))
        evidence=_evidence(scoped,provisions)
    if not rows or not evidence:
        emit('evidence','abstained','No returned facts with verifiable source provenance were found.')
        return finish(result)
    from chatbot.lineage import build_lineage
    lineage=build_lineage(folder,g,evidence,query,rows)
    emit('evidence','complete',f'Linked {len(evidence)} source clause(s) to requirements, plans and graph facts.')
    emit('answer','running','Formatting graph facts while retaining policy conditions.' if mode=='demo' else 'Synthesizing an answer from returned facts and verified source evidence.')
    if mode=='demo':
        answer=row_answer(rows)
        conditions=' '.join(c for e in evidence for c in e['conditions'])
        if conditions:answer+='\n\nSource conditions: '+conditions
    else:answer=llm.call('synthesis',{'question':question,'rows':rows,'evidence':evidence},Answer).answer
    result.update(answer=answer,abstained=False,evidence=evidence,lineage=lineage)
    emit('answer','complete','The answer is ready. Source clauses and graph lineage are available for inspection.')
    return finish(result)
