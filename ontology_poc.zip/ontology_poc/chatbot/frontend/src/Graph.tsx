import {useEffect,useMemo,useState} from 'react';
import {Network} from 'lucide-react';
import type {Response,GraphNode} from './types';
export default function Graph({response}:{response:Response}) {
 const [selected,setSelected]=useState<GraphNode|null>(null);
 const lineage=response.lineage;
 useEffect(()=>setSelected(null),[response]);
 const layout=useMemo(()=>{
  if(!lineage)return [];
  const group=(n:GraphNode)=>n.type==='Policy'?0:n.type==='Provision'?1:n.type==='literal'?4:n.type==='Person'?3:2;
  const columns=[0,1,2,3,4].map(i=>lineage.nodes.filter(n=>group(n)===i));
  return columns.flatMap((list,col)=>list.map((node,i)=>({...node,x:20+col*205,y:38+i*100,col})));
 },[lineage]);
 if(!lineage)return <p className="muted">No supporting graph was retrieved for this answer.</p>;
 const height=Math.max(240,...layout.map(n=>n.y+105));
 return <div className="actual-graph"><div className="section-label"><Network size={15}/> Graph facts used for this answer <span>{lineage.edges.length} actual edges</span></div>
  <div className="graph-scroll"><svg viewBox={`0 0 1040 ${height}`} role="img" aria-label="Graph lineage from the selected policy to source pages and retrieved facts">
   <defs><marker id="arrow" markerWidth="7" markerHeight="7" refX="6" refY="3.5" orient="auto"><path d="M0,0 L7,3.5 L0,7" fill="#a9b7bd"/></marker></defs>
   {lineage.edges.map((edge,i)=>{const a=layout.find(n=>n.id===edge.source),b=layout.find(n=>n.id===edge.target);if(!a||!b)return null;const sx=a.x+174,sy=a.y+29,tx=b.x,ty=b.y+29;return <g key={i}><path d={`M${sx},${sy} C${sx+35},${sy} ${tx-35},${ty} ${tx},${ty}`} fill="none" stroke="#b4c2c8" strokeWidth="1.4" markerEnd="url(#arrow)"/><text x={(sx+tx)/2} y={(sy+ty)/2-5} textAnchor="middle" className="edge-label">{edge.label}</text></g>})}
   {layout.map(n=><g key={n.id} tabIndex={0} role="button" aria-label={`Inspect graph node ${n.label}`} onClick={()=>setSelected(n)} onKeyDown={e=>{if(e.key==='Enter'||e.key===' ')setSelected(n)}} className={`graph-node ${selected?.id===n.id?'selected':''}`}>
    <rect x={n.x} y={n.y} width="174" height="60" rx="9" fill={n.type==='literal'?'#f3f7f6':n.type==='Provision'?'#e5f3ee':'#fff'} stroke={selected?.id===n.id?'#2e8e77':'#dce5e5'}/>
    <text x={n.x+12} y={n.y+20} className="node-type">{n.type}</text><text x={n.x+12} y={n.y+42} className="node-label">{n.label.length>23?n.label.slice(0,21)+'…':n.label}</text>
   </g>)}
  </svg></div>
  {selected&&<div className="node-detail"><b>{selected.type}</b><span>{selected.label}</span>{selected.uri&&<code>{selected.uri}</code>}</div>}
  <p className="micro">This view uses triples read from the selected ontology, rather than a generic architecture diagram. Select a node to inspect its value.</p>
 </div>
}
