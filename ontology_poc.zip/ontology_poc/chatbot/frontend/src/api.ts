import type {Progress,Response} from './types';
export async function getJSON(url:string) {
 const response=await fetch(url);
 if(!response.ok) {let text='The request could not be completed.';try{text=(await response.json()).detail||text}catch{}throw new Error(text)}
 return response.json();
}
export async function streamChat(body:object,onProgress:(event:Progress)=>void):Promise<Response> {
 const response=await fetch('/api/chat/stream',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});
 if(!response.ok){let detail='Unable to start the query.';try{detail=(await response.json()).detail||detail}catch{}throw new Error(detail)}
 if(!response.body)throw new Error('Your browser could not read the progress stream.');
 const reader=response.body.getReader(),decoder=new TextDecoder();let buffer='',result:Response|undefined;
 const consume=(block:string)=>{
  const kind=block.split('\n').find(l=>l.startsWith('event:'))?.slice(6).trim();
  const raw=block.split('\n').filter(l=>l.startsWith('data:')).map(l=>l.slice(5).trim()).join('\n');
  if(!raw)return;
  const data=JSON.parse(raw);
  if(kind==='progress')onProgress(data);
  if(kind==='result')result=data;
  if(kind==='error')throw new Error(data.message||'The backend could not complete the query.');
 };
 try {
  while(true){const {value,done}=await reader.read();if(done)break;buffer+=decoder.decode(value,{stream:true});let boundary;
   while((boundary=buffer.indexOf('\n\n'))>=0){consume(buffer.slice(0,boundary));buffer=buffer.slice(boundary+2)}
  }
  if(buffer.trim())consume(buffer);
 } finally {reader.releaseLock()}
 if(!result)throw new Error('The connection ended before the backend returned an answer. Please retry.');
 return result;
}
export function downloadJSON(name:string,value:unknown){const blob=new Blob([JSON.stringify(value,null,2)],{type:'application/json'});const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(url),1000)}
