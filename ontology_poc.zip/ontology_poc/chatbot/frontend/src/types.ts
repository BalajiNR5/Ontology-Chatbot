export type Progress = {stage:string;state:'running'|'complete'|'abstained';detail:string;elapsed_ms:number};
export type Evidence = {document_id:string;page:number;quote:string;provision:string;conditions:string[]};
export type GraphNode = {id:string;label:string;type:string;uri:string|null};
export type GraphEdge = {source:string;target:string;predicate:string;label:string};
export type Trace = {document_id:string;page:number;quote:string;provision:string;requirements:any[];designs:any[];artifacts:Record<string,{id:string;available:boolean;filename:string}>;qa_status:string|null;architectural_review_method:string|null};
export type Response = {question:string;document_id:string;answer:string;abstained:boolean;rows:Record<string,string>[];sparql:string|null;evidence:Evidence[];mode:string;duration_ms:number;timeline:Progress[];lineage:null|{traces:Trace[];nodes:GraphNode[];edges:GraphEdge[];ontology_sha256:string;scope:string}};
export type Workspace = {run:{id:string;mode:string;status:string;human_review_status:string};runs:{id:string;mode:string;label:string}[];contracts:{id:string;name:string;pages:number;provisions:number;synthetic:boolean;pdf_url:string;type:string}[];statistics:Record<string,number>;validation:Record<string,any>;live_model_configured:boolean};
