"""Trace source -> SRD -> TIP -> concrete graph facts -> query/answer.

Every edge displayed by the web UI is read from the selected ontology. Missing
agent artifacts are reported as unavailable, never synthesized as evidence.
"""
import hashlib
from pathlib import Path
from rdflib import URIRef,Literal
from rdflib.namespace import RDF,RDFS
from ontology.graph import EX,DATA,new_graph
from agents.io import read_json,normalize

ARTIFACTS={'srd':'01_srd.json','tip':'02_tip.json','candidate':'03_candidate.ttl','qa':'04_qa_0.json'}

def build_lineage(folder,graph,evidence,query,rows):
    folder=Path(folder);traces=[];nodes={};edges=[];seen_edges=set()
    def add_node(value,kind=None):
        identity=str(value)
        if identity in nodes:return
        typ=graph.value(value,RDF.type) if isinstance(value,URIRef) else None
        label=str(graph.value(value,RDFS.label) or identity.rsplit('/',1)[-1].rsplit('#',1)[-1]) if isinstance(value,URIRef) else str(value)
        nodes[identity]={'id':identity,'label':label,'type':kind or ('literal' if isinstance(value,Literal) else str(typ or 'Resource').rsplit('#',1)[-1]),
                         'uri':identity if isinstance(value,URIRef) else None}
    def add_edge(s,p,o):
        triple=(str(s),str(p),str(o))
        if triple in seen_edges:return
        seen_edges.add(triple);add_node(s);add_node(o)
        edges.append({'source':str(s),'target':str(o),'predicate':str(p),'label':str(p).rsplit('#',1)[-1]})
    for e in evidence:
        doc=e['document_id'];page=e['page'];node=URIRef(e['provision']);policy=DATA[doc]
        page_dir=folder/'agents'/doc/f'page_{page:03d}'
        artifacts={key:({'id':f'{doc}:{page}:{key}','available':True,'filename':name} if (page_dir/name).is_file() else
                        {'id':f'{doc}:{page}:{key}','available':False,'filename':name}) for key,name in ARTIFACTS.items()}
        # QA may have accepted a later repair attempt; link the actually accepted QA report.
        qa_files=sorted(page_dir.glob('04_qa_*.json'))
        if qa_files:artifacts['qa']={'id':f'{doc}:{page}:qa','available':True,'filename':qa_files[-1].name}
        requirements=[];designs=[]
        if artifacts['srd']['available']:
            srd=read_json(page_dir/ARTIFACTS['srd'])
            requirements=[r for r in srd.get('requirements',[]) if normalize(r.get('evidence_quote',''))==normalize(e['quote'])]
        if artifacts['tip']['available']:
            tip=read_json(page_dir/ARTIFACTS['tip']);ids={r['id'] for r in requirements}
            designs=[d for d in tip.get('conceptual_model',[]) if d.get('concept') in ids]
            # Live vocabulary can use concept names instead of requirement ids.
            if not designs and requirements:
                concepts={c['name'] for r in requirements for c in r.get('concepts',[])}
                designs=[d for d in tip.get('conceptual_model',[]) if d.get('concept') in concepts]
        qa=read_json(page_dir/artifacts['qa']['filename']) if artifacts['qa']['available'] else None
        traces.append({'document_id':doc,'page':page,'provision':str(node),'quote':e['quote'],
                       'source_uri':str(graph.value(node,EX.sourcePage)),'requirements':requirements,'designs':designs,
                       'artifacts':artifacts,'qa_status':qa.get('architectural',{}).get('status') if qa else None,
                       'architectural_review_method':qa.get('architecture_review_method') if qa else None})
        for triple in graph.triples((policy,EX.hasProvision,node)):add_edge(*triple)
        for predicate in [EX.sourcePage,EX.hasAmount,EX.hasInterval,EX.hasQuantity,EX.hasRole,EX.hasEvent,EX.hasRule]:
            for child in graph.objects(node,predicate):
                add_edge(node,predicate,child)
                for p2 in [EX.value,EX.currency,EX.unit,EX.heldBy,EX.inPolicy,EX.hasEntitledRole]:
                    for leaf in graph.objects(child,p2):
                        add_edge(child,p2,leaf)
                        if p2 in [EX.heldBy,EX.hasEntitledRole]:
                            for p3 in [EX.heldBy,RDFS.label]:
                                for last in graph.objects(leaf,p3):add_edge(leaf,p3,last)
        source=graph.value(node,EX.sourcePage)
        if source:
            for p in [EX.documentId,EX.pageNumber]:
                for value in graph.objects(source,p):add_edge(source,p,value)
    path=folder/'ontology.ttl'
    return {'traces':traces,'nodes':list(nodes.values()),'edges':edges,'sparql':query,'returned_rows':rows,
            'ontology_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),
            'scope':'Actual selected graph triples and retained page-level artifacts. No lineage stage was regenerated for this chat.'}
