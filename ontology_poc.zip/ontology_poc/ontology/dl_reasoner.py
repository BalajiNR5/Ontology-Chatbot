"""Isolated HermiT execution; failure is explicit and never marked consistent."""
import json,sys
from pathlib import Path

def main():
    try:
        from owlready2 import World,sync_reasoner, OwlReadyInconsistentOntologyError
        world=World();onto=world.get_ontology(Path(sys.argv[1]).resolve().as_uri()).load()
        try:
            sync_reasoner(world,debug=0,infer_property_values=True)
            unsatisfiable=[str(c) for c in world.inconsistent_classes() if str(c)!='owl.Nothing']
            print(json.dumps({'status':'fail' if unsatisfiable else 'pass','engine':'HermiT','unsatisfiable_classes':unsatisfiable}))
        except OwlReadyInconsistentOntologyError:
            print(json.dumps({'status':'fail','engine':'HermiT','error':'Inconsistent ontology'}))
    except Exception as e:
        print(json.dumps({'status':'error','engine':'HermiT','error':str(e)[:400]}))
if __name__=='__main__':main()
