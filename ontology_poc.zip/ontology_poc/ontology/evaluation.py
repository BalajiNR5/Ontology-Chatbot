import statistics,re
from pathlib import Path
from agents.io import ROOT,read_json,write_json
from ontology.graph import new_graph,registry,DATA
from ontology.query import safe_query,scoped_graph,fixture_query,row_answer
from agents.llm import LLM
from agents.models import QueryOutput,Score

def exact_score(answer,expected):
    def clean(s):return re.sub(r'\s+',' ',s).strip().lower().rstrip('.')
    return 1.0 if clean(answer)==clean(expected) else 0.0

def evaluate(run_dir,mode='demo',split='all',method='sparql'):
    folder=Path(run_dir);g=new_graph().parse(folder/'ontology.ttl',format='turtle')
    run=read_json(folder/'run_manifest.json')
    cqs=[]
    for name in ['development','heldout'] if split=='all' else [split]:
        cqs.extend(read_json(ROOT/f'data/cqs/{name}.json'))
    cqs=[q for q in cqs if q['document_id'] in run['documents']]
    llm=LLM(folder/'evaluation_calls') if mode=='llm' else None
    judge=LLM(folder/'judge_calls',judge=True) if mode=='llm' else None
    reports=[]
    for cq in cqs:
        scoped=scoped_graph(g,cq['document_id']);attempts=[];feedback=[];score=0;answer='';query='';rows=[]
        if method=='vector':
            if not llm:raise ValueError('Vector synthesis/adjudication requires --mode llm')
            from ontology.retrieval import vector_answer
            response=vector_answer(scoped,cq['question'],llm)
            answer=response.answer
            judgment=judge.call('judge',{'question':cq['question'],'expected':cq['expected'],'answer':answer,'evidence':response.evidence},Score)
            score=judgment.score;attempts=[{'answer':answer,'score':score,'judgment':judgment.justification}]
        else:
            import os
            for attempt in range(int(os.getenv('MAX_QUERY_ATTEMPTS','3')) if llm else 1):
                try:
                    # Ground truth deliberately withheld from the query-generation agent.
                    query=llm.call('query',{'question':cq['question'],'contract_uri':str(DATA[cq['document_id']]),
                              'ontology_registry':registry(scoped),'ontology_turtle':scoped.serialize(format='turtle'),'feedback':feedback},QueryOutput).sparql if llm else fixture_query(cq)
                    rows=safe_query(scoped,query);answer=row_answer(rows)
                    if llm and rows:
                        judgment=judge.call('judge',{'question':cq['question'],'expected':cq['expected'],'actual_rows':rows,'answer':answer},Score)
                        score=judgment.score;reason=judgment.justification
                    else:score=exact_score(answer,cq['expected']) if rows else 0;reason='Exact normalized comparison' if rows else 'Empty results'
                    attempts.append({'query':query,'rows':rows,'answer':answer,'score':score,'judgment':reason})
                    if score>0:break
                    feedback.append('The query returned no correct facts. Check vocabulary and graph paths.')
                except Exception as e:
                    feedback.append(str(e)[:500]);attempts.append({'query':query,'error':str(e)[:500],'score':0})
        reports.append({**cq,'answer':answer,'score':score,'attempts':attempts})
    summary={'mode':mode,'method':method,'is_llm_measured':bool(llm),'generation_mode':run['mode'],
             'total':len(reports),'fully_correct':sum(r['score']==1 for r in reports),
             'mean_score':statistics.mean(r['score'] for r in reports) if reports else 0,
             'splits':{s:{'total':sum(r['split']==s for r in reports),
                         'mean_score':statistics.mean(r['score'] for r in reports if r['split']==s) if any(r['split']==s for r in reports) else None} for s in ['development','heldout']},
             'interpretation':'Curated fixture regression only; not LLM performance or paper reproduction.' if not llm else 'Model-mediated evaluation; independent human review remains pending.'}
    report={'summary':summary,'results':reports};write_json(folder/f'evaluation_{method}_{mode}_{split}.json',report)
    lines=['# Competency question evaluation','',summary['interpretation'],'',f"Correct: {summary['fully_correct']}/{summary['total']}; mean score: {summary['mean_score']:.4f}",'', '| CQ | Split | Score | Actual answer |','|---|---|---:|---|']
    lines += [f"| {r['id']} | {r['split']} | {r['score']} | {r['answer'].replace('|',' / ')} |" for r in reports]
    (folder/f'evaluation_{method}_{mode}_{split}.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
    return report
