from rdflib import Graph, Namespace, Literal, URIRef
from rdflib.namespace import RDF,RDFS,OWL,XSD
from agents.io import normalize
EX=Namespace('https://example.org/insurance#')
DATA=Namespace('https://example.org/insurance/data/')
PROV=Namespace('http://www.w3.org/ns/prov#')

def new_graph():
    g=Graph()
    for key,ns in [('ex',EX),('data',DATA),('owl',OWL),('rdf',RDF),('rdfs',RDFS),('xsd',XSD),('prov',PROV)]:g.bind(key,ns)
    return g

def reference_schema():
    """Demo schema only. Live generation starts with namespaces and metadata, not this schema."""
    g=new_graph(); g.add((EX.InsuranceOntology,RDF.type,OWL.Ontology))
    classes=['Policy','Provision','SourcePage','Person','Role','MonetaryAmount','TimeInterval','Quantity','Event','DeathBenefitEvent','ConditionalRule']
    for name in classes:
        g.add((EX[name],RDF.type,OWL.Class));g.add((EX[name],RDFS.label,Literal(name)))
    g.add((EX.DeathBenefitEvent,RDFS.subClassOf,EX.Event))
    g.add((EX.TimeInterval,RDFS.subClassOf,EX.Quantity))
    g.add((EX.Person,OWL.disjointWith,EX.Role))
    g.add((EX.MonetaryAmount,OWL.disjointWith,EX.TimeInterval))
    objects={'hasProvision':('Policy','Provision'),'sourcePage':('Provision','SourcePage'),
             'hasAmount':('Provision','MonetaryAmount'),'hasInterval':('Provision','TimeInterval'),
             'hasQuantity':('Provision','Quantity'),'hasRole':('Provision','Role'),'heldBy':('Role','Person'),'inPolicy':('Role','Policy'),
             'hasEvent':('Provision','Event'),'hasRule':('Provision','ConditionalRule'),
             'hasEntitledRole':('Event','Role')}
    datas={'documentId':(None,XSD.string),'pageNumber':('SourcePage',XSD.integer),'pageText':('SourcePage',XSD.string),
           'kind':('Provision',XSD.string),'statement':('Provision',XSD.string),'evidenceQuote':('Provision',XSD.string),
           'value':(None,XSD.decimal),'currency':('MonetaryAmount',XSD.string),'unit':('Quantity',XSD.string),
           'condition':(None,XSD.string)}
    for name,(dom,rng) in objects.items():
        g.add((EX[name],RDF.type,OWL.ObjectProperty));g.add((EX[name],RDFS.domain,EX[dom]));g.add((EX[name],RDFS.range,EX[rng]))
    for name,(dom,rng) in datas.items():
        g.add((EX[name],RDF.type,OWL.DatatypeProperty));g.add((EX[name],RDFS.range,rng))
        if dom:g.add((EX[name],RDFS.domain,EX[dom]))
    return g

def add_source(g,page):
    policy=DATA[page.document_id];src=DATA[f'{page.document_id}/page/{page.page}']
    g.add((policy,RDF.type,EX.Policy));g.add((policy,EX.documentId,Literal(page.document_id,datatype=XSD.string)))
    g.add((src,RDF.type,EX.SourcePage));g.add((src,EX.documentId,Literal(page.document_id,datatype=XSD.string)))
    g.add((src,EX.pageNumber,Literal(page.page,datatype=XSD.integer)))
    g.add((src,EX.pageText,Literal(normalize(page.text),datatype=XSD.string)))
    return policy,src

def add_fixture(g,page,facts):
    policy,src=add_source(g,page)
    for f in facts:
        node=DATA[f['id']];g.add((node,RDF.type,EX.Provision));g.add((policy,EX.hasProvision,node))
        g.add((node,EX.sourcePage,src));g.add((node,EX.documentId,Literal(page.document_id,datatype=XSD.string)))
        for k,v in [('kind',f['kind']),('statement',f['statement']),('evidenceQuote',f['quote'])]:g.add((node,EX[k],Literal(v,datatype=XSD.string)))
        for condition in f['conditions']:g.add((node,EX.condition,Literal(condition,datatype=XSD.string)))
        if f['kind']=='money':
            amount=DATA[f['id']+'/amount'];g.add((node,EX.hasAmount,amount));g.add((amount,RDF.type,EX.MonetaryAmount))
            g.add((amount,EX.value,Literal(f['value'],datatype=XSD.decimal)));g.add((amount,EX.currency,Literal(f['unit'],datatype=XSD.string)))
        elif f['kind'] in ['interval','quantity']:
            interval=DATA[f['id']+'/interval'];g.add((node,EX.hasInterval if f['kind']=='interval' else EX.hasQuantity,interval));g.add((interval,RDF.type,EX.TimeInterval if f['kind']=='interval' else EX.Quantity))
            g.add((interval,EX.value,Literal(f['value'],datatype=XSD.decimal)));g.add((interval,EX.unit,Literal(f['unit'],datatype=XSD.string)))
        elif f['kind']=='role':
            person=DATA[page.document_id+'/person/'+f['person'].replace(' ','_')];role=DATA[f['id']+'/role']
            g.add((node,EX.hasRole,role));g.add((role,RDF.type,EX.Role));g.add((role,EX.heldBy,person));g.add((role,EX.inPolicy,policy))
            g.add((person,RDF.type,EX.Person));g.add((person,RDFS.label,Literal(f['person'])))
        elif f['kind']=='event':
            event=DATA[f['id']+'/conditional_event'];g.add((node,EX.hasEvent,event));g.add((event,RDF.type,EX.DeathBenefitEvent))
            g.add((event,EX.condition,Literal('Conditional policy obligation; not an observed death or actual payout.',datatype=XSD.string)))
            role=DATA[page.document_id+'_beneficiary/role'];g.add((event,EX.hasEntitledRole,role))
        else:
            rule=DATA[f['id']+'/rule'];g.add((node,EX.hasRule,rule));g.add((rule,RDF.type,EX.ConditionalRule))
    return g

def registry(g):
    terms=[]
    for t in [OWL.Class,OWL.ObjectProperty,OWL.DatatypeProperty]:
        for node in sorted(g.subjects(RDF.type,t),key=str):
            terms.append({'uri':str(node),'type':str(t).split('#')[-1],
                          'domain':[str(v) for v in g.objects(node,RDFS.domain)],
                          'range':[str(v) for v in g.objects(node,RDFS.range)]})
    return terms

def numbered(ttl): return '\n'.join(f'{i}: {line}' for i,line in enumerate(ttl.splitlines(),1))

def stats(g):
    return {'triples':len(g),'classes':len(set(g.subjects(RDF.type,OWL.Class))),
            'object_properties':len(set(g.subjects(RDF.type,OWL.ObjectProperty))),
            'datatype_properties':len(set(g.subjects(RDF.type,OWL.DatatypeProperty))),
            'provisions':len(set(g.subjects(RDF.type,EX.Provision))),
            'policies':len(set(g.subjects(RDF.type,EX.Policy)))}
