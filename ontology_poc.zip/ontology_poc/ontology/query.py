import re
from rdflib import Graph,URIRef
from rdflib.plugins.sparql import prepareQuery
from rdflib.plugins.sparql.parserutils import CompValue
from ontology.graph import EX,DATA,new_graph

PREFIX='PREFIX ex: <https://example.org/insurance#>\nPREFIX data: <https://example.org/insurance/data/>\nPREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>\n'

def scoped_graph(g,doc_id):
    """Only selected contract's reachable ABox plus explicit vocabulary definitions."""
    from rdflib.namespace import RDF,OWL
    out=new_graph();terms=set()
    for t in [OWL.Class,OWL.ObjectProperty,OWL.DatatypeProperty,OWL.Ontology]:terms.update(g.subjects(RDF.type,t))
    for term in terms:
        for triple in g.triples((term,None,None)):out.add(triple)
    frontier=[DATA[doc_id]];seen=set()
    while frontier:
        node=frontier.pop()
        if node in seen:continue
        seen.add(node)
        for triple in g.triples((node,None,None)):
            out.add(triple)
            if isinstance(triple[2],URIRef) and str(triple[2]).startswith(str(DATA)):frontier.append(triple[2])
    return out

def _has_triples(value):
    if isinstance(value,CompValue):
        if value.name=='BGP' and value.get('triples'):return True
        return any(_has_triples(v) for v in value.values())
    if isinstance(value,(list,tuple)):return any(_has_triples(v) for v in value)
    return False

def _has_extension(value):
    if isinstance(value,CompValue):
        if value.name=='Extend':return True
        return any(_has_extension(v) for v in value.values())
    if isinstance(value,(list,tuple)):return any(_has_extension(v) for v in value)
    return False

def safe_query(g,query,max_rows=100):
    # Conservative rejection even inside string literals is intentional for this PoC.
    if re.search(r'\b(SERVICE|FROM|LOAD|INSERT|DELETE|CLEAR|CREATE|DROP|COPY|MOVE|ADD|WITH|BIND|VALUES)\b',query,re.I):
        raise ValueError('Only local, fact-reading SELECT/ASK queries are supported; remote, update and answer-constant clauses are blocked.')
    prepared=prepareQuery(query)
    if prepared.algebra.name not in ['SelectQuery','AskQuery']:raise ValueError('Only SELECT and ASK queries are supported')
    if not _has_triples(prepared.algebra):raise ValueError('Query must read graph triples')
    if _has_extension(prepared.algebra):raise ValueError('Projection expressions are disabled; return graph-bound variables')
    for variable in prepared.algebra.get('PV',[]):
        if not hasattr(variable,'n3'):raise ValueError('Invalid projection')
    result=g.query(prepared)
    if result.type=='ASK':return [{'ask':bool(result.askAnswer)}]
    rows=[]
    for row in result:
        rows.append({str(k):str(v) for k,v in row.asdict().items()})
        if len(rows)>=max_rows:break
    return rows

def fixture_query(cq):
    node=URIRef(str(DATA)+cq['fact_id']).n3()
    base=f'{node} ex:sourcePage ?source . ?source ex:pageNumber ?page .'
    kind=cq['kind']
    if kind=='money':body=f'{node} ex:hasAmount ?amount . ?amount ex:value ?value ; ex:currency ?unit .';select='?value ?unit ?page'
    elif kind in ['interval','quantity']:
        prop='hasInterval' if kind=='interval' else 'hasQuantity'
        body=f'{node} ex:{prop} ?interval . ?interval ex:value ?value ; ex:unit ?unit .';select='?value ?unit ?page'
    elif kind=='role':body=f'{node} ex:hasRole ?role . ?role ex:heldBy ?person . ?person rdfs:label ?name .';select='?name ?page'
    else:body=f'{node} ex:statement ?statement .';select='?statement ?page'
    return PREFIX+f'SELECT {select} WHERE {{ {body} {base} }}'

def row_answer(rows):
    answers=[]
    for row in rows:
        if 'value' in row:
            from decimal import Decimal
            try:value=format(Decimal(row['value']).normalize(),'f')
            except Exception:value=row['value']
            answers.append(value+' '+row.get('unit',''))
        elif 'name' in row:answers.append(row['name'])
        elif 'statement' in row:answers.append(row['statement'])
        elif 'ask' in row:answers.append(str(row['ask']))
        else:answers.append('; '.join(f'{k}: {v}' for k,v in row.items() if k!='page'))
    return ' | '.join(sorted(set(answers)))
