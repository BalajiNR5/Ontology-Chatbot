"""Optional paper-style dense graph retrieval: node + edge indexes, two-hop expansion."""
import numpy as np
from rdflib import URIRef
from chatbot.core import Answer
from ontology.graph import EX

def vector_answer(graph,question,llm,top_k=5):
    from sentence_transformers import SentenceTransformer
    triples=list(graph)
    # Page text is excluded so retrieval actually uses the ontology, not a PDF text shortcut.
    triples=[t for t in triples if t[1]!=EX.pageText]
    nodes=sorted({str(s) for s,p,o in triples}|{str(o) for s,p,o in triples})
    edges=[' '.join(map(str,t)) for t in triples]
    model=SentenceTransformer('sentence-transformers/all-MiniLM-L6-v2')
    query=model.encode([question],normalize_embeddings=True)[0]
    node_vectors=model.encode(nodes,normalize_embeddings=True)
    edge_vectors=model.encode(edges,normalize_embeddings=True)
    node_idx=np.argsort(node_vectors@query)[-top_k:];edge_idx=np.argsort(edge_vectors@query)[-top_k:]
    seeds={nodes[i] for i in node_idx}
    selected={triples[i] for i in edge_idx}
    seeds.update(str(x) for t in selected for x in [t[0],t[2]])
    frontier=seeds
    for _ in range(2):
        found={t for t in triples if str(t[0]) in frontier or str(t[2]) in frontier}
        selected|=found
        frontier={str(x) for t in found for x in [t[0],t[2]]}-seeds
        seeds|=frontier
    context=[' '.join(map(str,t)) for t in sorted(selected,key=lambda t:tuple(map(str,t)))]
    return llm.call('synthesis',{'question':question,'ontology_subgraph_triples':context,
                   'retrieval_method':'Separate MiniLM node and edge dense indexes, cosine-only (paper weight beta=10), two-hop expansion.'},Answer)
