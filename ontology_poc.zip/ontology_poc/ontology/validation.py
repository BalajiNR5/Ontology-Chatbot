from pathlib import Path
import hashlib, json, subprocess, sys, tempfile
from rdflib import Graph,URIRef
from rdflib.namespace import RDF, RDFS, OWL
from owlrl import DeductiveClosure, OWLRL_Semantics
from pyshacl import validate as shacl_validate
from agents.io import ROOT,normalize
from ontology.graph import EX,DATA,registry,new_graph

def validate_turtle(turtle,pages=None,require_dl=False):
    result={'passed':False,'syntax':{'status':'not_run'},'shacl':{'status':'not_run'},
            'provenance':{'status':'not_run'},'owl_rl':{'status':'not_run'},'owl_dl':{'status':'not_run'}}
    g=new_graph()
    try:g.parse(data=turtle,format='turtle');result['syntax']={'status':'pass'}
    except Exception as e:
        result['syntax']={'status':'fail','error':str(e)[:1200]};return result,None
    # Remote imports are never loaded. Fail rather than pretending to have checked them.
    if list(g.triples((None,OWL.imports,None))):
        result['syntax']={'status':'fail','error':'owl:imports is disabled. Bundle reviewed vocabularies locally.'};return result,g
    conforms,_,report=shacl_validate(g,shacl_graph=str(ROOT/'ontology/shapes.ttl'),inference='rdfs',advanced=False)
    result['shacl']={'status':'pass' if conforms else 'fail','report':str(report)}
    errors=[]
    trusted={(p.document_id,p.page):normalize(p.text) for p in pages or []}
    for node in g.subjects(RDF.type,EX.Provision):
        source=g.value(node,EX.sourcePage); quote=g.value(node,EX.evidenceQuote)
        if source is None or quote is None:errors.append(f'{node}: missing provenance');continue
        doc=str(g.value(source,EX.documentId) or '')
        try:page=int(g.value(source,EX.pageNumber))
        except (ValueError,TypeError):errors.append(f'{node}: invalid source page');continue
        text=str(g.value(source,EX.pageText) or '')
        if trusted:
            if (doc,page) not in trusted:errors.append(f'{node}: unknown source page');continue
            if normalize(text)!=trusted[(doc,page)]:errors.append(f'{node}: altered source text')
            text=trusted[(doc,page)]
        if not normalize(str(quote)) or normalize(str(quote)) not in normalize(text): errors.append(f'{node}: unsupported quote')
        if str(g.value(node,EX.documentId))!=doc:errors.append(f'{node}: document provenance mismatch')
        policy=DATA[doc]
        if (policy,EX.hasProvision,node) not in g:errors.append(f'{node}: missing policy scope')
    if not list(g.subjects(RDF.type,EX.Provision)):errors.append('No provenance-bearing provisions were generated')
    result['provenance']={'status':'fail' if errors else 'pass','errors':errors,'trust':'original parsed pages' if trusted else 'embedded pages only'}
    inferred=new_graph()
    for triple in g:inferred.add(triple)
    DeductiveClosure(OWLRL_Semantics).expand(inferred)
    contradictions=[]
    for a,_,b in inferred.triples((None,OWL.disjointWith,None)):
        for individual in inferred.subjects(RDF.type,a):
            if (individual,RDF.type,b) in inferred:contradictions.append(f'{individual} has disjoint types {a} and {b}')
    for individual in inferred.subjects(RDF.type,OWL.Nothing):contradictions.append(f'{individual} is owl:Nothing')
    # Property declarations must remain explicit for TBox inspection.
    vocabulary_errors=[]
    for term in registry(g):
        if term['type'] in ['ObjectProperty','DatatypeProperty'] and not term['range']:
            vocabulary_errors.append(f"{term['uri']}: missing range")
    result['owl_rl']={'status':'fail' if contradictions or vocabulary_errors else 'pass',
                      'contradictions':contradictions,'vocabulary_errors':vocabulary_errors,
                      'inferred_triples_added':len(inferred)-len(g),
                      'scope':'OWL RL closure and selected contradiction checks; not a complete OWL DL consistency proof'}
    if require_dl:
        with tempfile.TemporaryDirectory() as temp:
            path=Path(temp)/'ontology.owl';g.serialize(path,format='xml')
            proc=subprocess.run([sys.executable,'-m','ontology.dl_reasoner',str(path)],capture_output=True,text=True,timeout=90)
            try:dl=json.loads(proc.stdout)
            except ValueError:dl={'status':'error','error':'Reasoner failed to return JSON; install owlready2 and Java.'}
            result['owl_dl']=dl
    else:result['owl_dl']={'status':'not_requested','scope':'Use --require-dl for HermiT consistency gate; Java and owlready2 required.'}
    required=['syntax','shacl','provenance','owl_rl']+(['owl_dl'] if require_dl else [])
    result['passed']=all(result[k]['status']=='pass' for k in required)
    return result,g

def patch_turtle(turtle,patches):
    for patch in patches:
        if not patch.old or turtle.count(patch.old)!=1:raise ValueError('Repair old snippet must occur exactly once')
        turtle=turtle.replace(patch.old,patch.new,1)
    return turtle
